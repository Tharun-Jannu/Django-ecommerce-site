from django.apps import AppConfig


class WearsConfig(AppConfig):
    name = 'wears'
